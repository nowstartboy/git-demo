
wget eecs.berkeley.edu/~rich.zhang/projects/2016_colorization/files/train/caffe-colorization.tar.gz -O ./caffe-colorization.tar.gz
tar -xvf ./caffe-colorization.tar.gz
rm ./caffe-colorization.tar.gz
