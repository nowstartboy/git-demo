
./caffe-colorization/build/tools/caffe test -model ./models/colorization_train_val_v2.prototxt -weights $1 -gpu $2 -iterations $3
